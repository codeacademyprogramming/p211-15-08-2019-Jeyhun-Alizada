﻿--create database Library
use Library
--create table Author( Id int primary key identity, Name nvarchar(20) not null, Surname nvarchar(20) not null)
--create table Book(Id int primary key identity, Name nvarchar(20) not null, Author_Id int references Author(Id)  not null, PublishYear date not null, Count int not null)
--create table Faculty(Id int primary key, Name nvarchar(20) not null)
--create table Student (Id int primary key identity,Name nvarchar(20) not null, Surname nvarchar(20) not null, CardNumber int unique not null, Faculty_Id int references Faculty(Id))
--create table Registration(Id int primary key identity , RegDate date not null, Book_Id int references Book(Id) not null, Student_Id int references Student(Id) not null)
select 
	Student.Name 'Tələbə adı',
	Student.Surname 'Tələbə soyadı',
	Student.CardNumber 'Bilet nömrəsi',
	Faculty.Name 'Fakültə adı',
	Book.Name 'Kitab adı',
	Author.Name 'Yazıçı adı',
	format(Book.PublishYear, 'yyyy') 'Çap ili',
	Book.Count 'Kitab qalığı',
	Book.Name 'Götürülmə vaxtı'
from  Registration
join Student on Student_Id = Student.Id
join Book on Book_Id= Book.Id
join Author  on Author_Id = Author.Id
join Faculty on Faculty_Id = Faculty.Id