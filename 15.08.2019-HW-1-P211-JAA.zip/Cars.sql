﻿--create table Brends (Id int primary key identity,Name nvarchar(20) not null);
--select * from Brends;
--create table Models (Id int primary key identity, Name nvarchar(20) not null, Brend_Id int not null references Brends(Id));
--create table Fules ( Id int primary key identity, Name nvarchar(20) unique not null);
--create table Colors ( Id int primary key identity, Name nvarchar(20) unique not null);
--create table Transmission ( Id int primary key identity, Name nvarchar(20) unique not null);
--create table EngineCapacity (Id int primary key identity, Volume int unique);
--create table Advertisements (Id int primary key identity, 
--							Model_Id int not null references Models(Id), 
--							Color_Id int not null references Colors(Id), 
--							Fules_Id int not null references  Fules(Id), 
--							Transmission_Id int not null references Transmission(Id), 
--							EngineCapacity_Id int not null references EngineCapacity(Id),
--							Price int not null,
--							Mileage int not null,
--							YearOfIssue date not null check(getdate() >= YearOfIssue));
use Cars
select 
	Brends.Name 'Marka',
	Models.Name 'Model',
	Advertisements.Price 'Qiymət',
	Colors.Name 'Rəng',
	format(Advertisements.YearOfIssue, 'yyyy') 'Buraxılış ili',
	Transmission.Name 'Sürətlər qutusu',
	Fules.Name 'Yanacaq növü',
	EngineCapacity.Volume 'Mühərrikin həcmi',
	Advertisements.Mileage 'Yürüş'
from Advertisements 
join Models  on Model_Id = Models.Id
join Brends on Brend_Id= Brends.Id
join Fules on Fules_Id = Fules.Id
join Colors on Color_Id = Colors.Id
join Transmission on Transmission_Id = Transmission.Id
join EngineCapacity on EngineCapacity_Id = EngineCapacity.Id







